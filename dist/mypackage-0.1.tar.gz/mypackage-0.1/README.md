# mypackage
This library was created as an example of how to publish your own Python mypackage

## building this package locally
'python setup.py sdist'

## installing this package from Github
'pip install git+git.website'

## updating this package from Github
'pip install --upgrade git+git.website'
